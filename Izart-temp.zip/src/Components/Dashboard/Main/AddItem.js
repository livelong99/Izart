import React, {useContext, useEffect, useState} from "react";
import firebase from "firebase/app";
import "firebase/firestore";
import "../fr.css";
import {DashContext} from "../../../Store";
import {UserContext} from "../../../Store";
import {CartContext} from "../../../Store";


const AddItm = () => {
    const db = firebase.firestore();

    const [dash, setDash] = useContext(DashContext);
    const [User, setUser] = useContext(UserContext);
    const [cart, setCart] = useContext(CartContext);
    const [projectName, setPro] = useState(null);
    const [date, setDate] = useState(null);
    const [product, setProduct] = useState(null);
    const [quantity, setQuo] = useState(null);
    const [landingpage, setLanding] = useState(null);
    const [nonlandingpage, setNonLandingPage] = useState(null);
    const [billablewords, setBillableWords] = useState(null);
    const [numberofposts, setNumberOfPosts] = useState(null);
    const [explanation, setExplanation] = useState(null);
    const [topic, setTopic] = useState(null);
    const [industry, setIndustry] = useState(null);
    const [contentgoals, setContentGoals] = useState(null);
    const [voice, setVoice] = useState(null);
    const [targetaudience, setTargetAudience] = useState(null);
    const [primarykeywords, setPrimaryKeywords] = useState(null);
    const [referencecontent, setReferenceContent] = useState(null);
    const [styletone, setStyleTone] = useState(null);
    const [linkingpreference, setLinkingPreference] = useState(null);
    const [additionalinformation, setAditionalInformation] = useState(null);
    const [attachment, setAttachment] = useState(null);
    // const [intr]

    const createData = (data) => {
        return db.collection('Cart').doc(User.uid).collection('Items').doc("01").set({
            created: firebase.firestore.FieldValue.serverTimestamp(),
            data
        })
    };

    const getData = () => {
        const k = db.collection('Cart').doc(User.uid).collection('Items')
            .get()
            .then((querySnapshot) => {
                let arr = [];
                querySnapshot.docs.map((doc) =>
                    arr.push({ id: doc.id, value: doc.data() })
                );
                setCart(arr);;
            },[db]);
    };


    const handleSubmit = (event) => {
            const data = {
             ProjectName : projectName,
             Date : date,
             Product: product,
             Quantity: quantity,
             LandigPage: landingpage,
             NonLandingPage: nonlandingpage,
             BillableWords: billablewords,
             NumberOfPosts: numberofposts,
             Explanation: explanation,
             Topic: topic,
             Industry: industry,
             ContentGoals: contentgoals,
             Voice: voice,
             TargetAudience: targetaudience,
             ReferenceContent: referencecontent,
             StyleTone: styletone,
             LinkingPreference: linkingpreference,
             AdditionalInformation: additionalinformation,
             Attachment: attachment
             
         };
         console.log(data);
         createData(data);
         event.preventDefault();
    }

    useEffect(() => {
        setDash(1);
        if(cart.length === 0)
            getData();

        

    })

    return(
        <div class="form-style-5">
            <form onSubmit={handleSubmit} id="add_item">
            <fieldset>
            <legend><span class="number">1</span> Project Details</legend>
            <label for="job">Project Name*</label>
            <input onBlur={(event) => {setPro(event.target.value)}} type="text" name="project_name" placeholder="Give your project a name" />
            <label for="deadline">Delivery Deadline</label>
            <input onBlur={(event) => {setDate(event.target.value)}} type="date" name="deadline" placeholder="Your Email *" />

            <legend><span class="number">2</span>Choose a Product*</legend>
            <label for="job">Product:</label>
            <select onBlur={(event) => {setProduct(event.target.value)}} id="product" name="product">
            <optgroup label="Services">
            <option value="whitepaper">Whitepaper</option>
            <option value="website_content">Website Content</option>
            <option value="technical_writing">Technical Writing</option>
            <option value="copy_writing">Copy Writing</option>
            <option value="blog_writing">Blog Writing</option>
            <option value="article_writing">Article Writing</option>
            <option value="lor">LOR</option>
            <option value="resume_cv">Resume/CV</option>
            <option value="sop">SOP</option>
            <option value="lor">LOR</option>
            <option value="cover_letter">Cover Letter</option>
            <option value="research_paper">Research Paper</option>
            </optgroup>
            </select>
            <label for="job">Quantity</label>
            <select onBlur={(event) => {setQuo(event.target.value)}} id="quantity" name="quantity">
            <optgroup label="Whitepaper">
            <option value="whitepaper">With Design</option>
            <option value="website_content">Without Design</option>
            </optgroup>
            </select>
            <textarea onBlur={(event) => {setLanding(event.target.value)}} name="landing" placeholder="Enter number of landing pages"></textarea>
            <textarea onBlur={(event) => {setNonLandingPage(event.target.value)}} name="nonlanding" placeholder="Enter number of non-landing pages"></textarea>
            <textarea onBlur={(event) => {setBillableWords(event.target.value)}} name="billable" placeholder="Enter number of billable words"></textarea>
            <textarea onBlur={(event) => {setNumberOfPosts(event.target.value)}} name="posts" placeholder="Enter number of posts"></textarea>
            <textarea onBlur={(event) => {setExplanation(event.target.value)}} name="explanation" placeholder="Enter explanation"></textarea>
            </fieldset>
            <fieldset>
            <legend><span class="number">3</span> Topic</legend>
            <textarea onBlur={(event) => {setTopic(event.target.value)}} name="topic" placeholder="Enter your Topic"></textarea>
            <legend><span class="number">4</span> Industry</legend>
            <select onBlur={(event) => {setIndustry(event.target.value)}} id="Industry" name="industry">
            <optgroup label="Industry">
            <option value="Software_and_Technology">Software and Technology</option>
            <option value="information_technology">Information Technology</option>
            <option value="marketing_and_advertisement">Marketing and Advertisement</option>
            <option value="finance">Finance</option>
            <option value="e_commerce">E-Commerce</option>
            <option value="academics">Academics</option>
            <option value="events_and_hospitality">Events and Hospitality</option>
            <option value="healthcare_and_sciences">Healthcare and Sciences</option>
            <option value="fashion">Fashion</option>
            <option value="travel">Travel</option>
            <option value="entertainment">Entertainment</option>
            <option value="sports_and_fitness">Sports and Fitness</option>
            </optgroup>
            </select>
            <legend><span class="number">5</span> Content Goals</legend>
            <textarea onBlur={(event) => {setContentGoals(event.target.value)}} name="contentgoals" placeholder="About Your School"></textarea>
            <legend><span class="number">6</span> Voice</legend>
            <textarea onBlur={(event) => {setVoice(event.target.value)}} name="voice" placeholder="About Your School"></textarea>
            <legend><span class="number">7</span> Target Audience</legend>
            <textarea onBlur={(event) => {setTargetAudience(event.target.value)}} name="targetaudience" placeholder="About Your School"></textarea>
            <legend><span class="number">8</span> Primary Keywords</legend>
            <textarea onBlur={(event) => {setPrimaryKeywords(event.target.value)}} name="primarykeywords" placeholder="About Your School"></textarea>
            <legend><span class="number">9</span> Reference Content</legend>
            <textarea onBlur={(event) => {setReferenceContent(event.target.value)}} name="referencecontent" placeholder="About Your School"></textarea>
            <legend><span class="number">10</span> Style and Tone</legend>
            <textarea onBlur={(event) => {setStyleTone(event.target.value)}} name="styletone" placeholder="About Your School"></textarea>
            <legend><span class="number">11</span> Referencing and Linking Preference</legend>
            <textarea onBlur={(event) => {setLinkingPreference(event.target.value)}} name="linkingpreference" placeholder="About Your School"></textarea>
            <legend><span class="number">12</span> Additional Information</legend>
            <textarea onBlur={(event) => {setAditionalInformation(event.target.value)}} name="additionalinformation" placeholder="About Your School"></textarea>
            <legend><span class="number">13</span> Add Attachment</legend>
            <input onBlur={(event) => {setAttachment(event.target.value)}} type="file" id="myfile" name="myfile"/>
            </fieldset>
            <input type="submit" value="Proceed" />
            </form>
        </div>
    )
}

export default AddItm;
