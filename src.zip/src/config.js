export const config = {
  apiKey: "AIzaSyD-l2eSilVUr8UHF-ouNetoCNQ3qSKlT50",
  authDomain: "izart-954b6.firebaseapp.com",
  projectId: "izart-954b6",
  storageBucket: "izart-954b6.appspot.com",
  messagingSenderId: "666130585049",
  appId: "1:666130585049:web:77366d1d482e26dcc035c8",
  measurementId: "G-P9KBW8E2SX"

  };