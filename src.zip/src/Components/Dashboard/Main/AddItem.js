import React, {useContext, useEffect, useState} from "react";
import firebase from "firebase/app";
import "firebase/firestore";
import "../fr.css";
import {DashContext} from "../../../Store";
import {UserContext} from "../../../Store";
import {CartContext} from "../../../Store";
import { DatePickerComponent } from '@syncfusion/ej2-react-calendars';
import price from "../../../OtherFiles/pricing.json";


const AddItm = () => {
    const db = firebase.firestore();

    const [dash, setDash] = useContext(DashContext);
    const [User, setUser] = useContext(UserContext);
    const [cart, setCart] = useContext(CartContext);
    const [projectName, setPro] = useState(null);
    const [delivery, setDelivery] = useState(null);
    const [date, setDate] = useState(null);
    const [product, setProduct] = useState(null);
    const [quantity, setQuo] = useState(1);
    const [landingpage, setLanding] = useState(null);
    const [nonlandingpage, setNonLandingPage] = useState(null);
    const [billablewords, setBillableWords] = useState(null);
    const [numberofposts, setNumberOfPosts] = useState(null);
    const [explanation, setExplanation] = useState(null);
    const [topic, setTopic] = useState(null);
    const [industry, setIndustry] = useState(null);
    const [contentgoals, setContentGoals] = useState(null);
    const [voice, setVoice] = useState(null);
    const [targetaudience, setTargetAudience] = useState(null);
    const [primarykeywords, setPrimaryKeywords] = useState(null);
    const [referencecontent, setReferenceContent] = useState(null);
    const [styletone, setStyleTone] = useState(null);
    const [linkingpreference, setLinkingPreference] = useState(null);
    const [additionalinformation, setAditionalInformation] = useState(null);
    const [attachment, setAttachment] = useState(null);
    const [sel, setSel] = useState(1);
    const [main, setMain] = useState(0);
    // const [intr]

    const createData = (data) => {
        return db.collection('Cart').doc(User.uid).collection('Items').doc(String(cart.length + 1)).set({
            created: firebase.firestore.FieldValue.serverTimestamp(),
            data
        }).then(() => {window.location.href="/dashboard/cart"; getData();})
    };

    const getData = () => {
        const k = db.collection('Cart').doc(User.uid).collection('Items')
            .get()
            .then((querySnapshot) => {
                let arr = [];
                querySnapshot.docs.map((doc) =>
                    arr.push({ id: doc.id, value: doc.data() })
                );
                setCart(arr);;
            },[db]);
    };


    const handleSubmit = (event) => {

        
        event.preventDefault();
        var data;
        if(sel ==  1){
            data = {
                ProjectName : projectName,
                Date : date,
                Product: product,
                Design: quantity,
                Explanation: explanation,
                Topic: topic,
                Industry: industry,
                ContentGoals: contentgoals,
                Voice: voice,
                TargetAudience: targetaudience,
                ReferenceContent: referencecontent,
                StyleTone: styletone,
                LinkingPreference: linkingpreference,
                AdditionalInformation: additionalinformation,
                Attachment: attachment
                
            };
        }

        else if(sel == 2){
            data = {
                ProjectName : projectName,
                Date : date,
                Product: product,
                LandigPage: landingpage,
                NonLandingPage: nonlandingpage,
                Explanation: explanation,
                Topic: topic,
                Industry: industry,
                ContentGoals: contentgoals,
                Voice: voice,
                TargetAudience: targetaudience,
                ReferenceContent: referencecontent,
                StyleTone: styletone,
                LinkingPreference: linkingpreference,
                AdditionalInformation: additionalinformation,
                Attachment: attachment
                
            };
        }

        else if(sel == 3){
            data = {
                ProjectName : projectName,
                Date : date,
                Product: product,
                BillableWords: billablewords,
                Explanation: explanation,
                Topic: topic,
                Industry: industry,
                ContentGoals: contentgoals,
                Voice: voice,
                TargetAudience: targetaudience,
                ReferenceContent: referencecontent,
                StyleTone: styletone,
                LinkingPreference: linkingpreference,
                AdditionalInformation: additionalinformation,
                Attachment: attachment
                
            };
        }

        else if(sel == 4){
            data = {
                ProjectName : projectName,
                Date : date,
                Product: product,
                Platform: quantity,
                NumberOfPosts: numberofposts,
                Explanation: explanation,
                Topic: topic,
                Industry: industry,
                ContentGoals: contentgoals,
                Voice: voice,
                TargetAudience: targetaudience,
                ReferenceContent: referencecontent,
                StyleTone: styletone,
                LinkingPreference: linkingpreference,
                AdditionalInformation: additionalinformation,
                Attachment: attachment
                
            };
        }

        else if(sel == 5){
            data = {
                ProjectName : projectName,
                Date : date,
                Product: product,
                Explanation: explanation,
                Topic: topic,
                Industry: industry,
                ContentGoals: contentgoals,
                Voice: voice,
                TargetAudience: targetaudience,
                ReferenceContent: referencecontent,
                StyleTone: styletone,
                LinkingPreference: linkingpreference,
                AdditionalInformation: additionalinformation,
                Attachment: attachment
                
            };
        }
        
        console.log(data);
        createData(data);
    }

    const minDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() +4);

    function onRenderDayCell(args) {
        if ((args.date).getDay() === 0 || (args.date).getDay() === 6) {
            args.isDisabled = true;
        }
    }

    function onDateChange(args){
        setDate(args.value);
        console.log(date);
    }

    useEffect(() => {
        setDash(1);
        if(cart.length === 0)
            getData();
        
        if(product == "Whitepaper"){
            setSel(1);
            setMain(1);
        }

        else if(product == "Website Content"){
            setSel(2);
            setMain(1)
        }
        else if(product == "Blog" || product == "Technical Write Up" || product == "Article"){
            setSel(3);
            setMain(1);
        }
        else if(product == "Social Media Post" || product == "Case Study" || product == "Product Description" || product == "Custom" || product == "Advertisement Script" || product == "SOP" || product == "Cover Letter" || product == "Research Paper" || product == "Resume"){
            setMain(2);
        }
        else{
            setSel(5)
        }
        

    })

    return(
        <div class="form-style-5">
            <form onSubmit={handleSubmit} id="add_item">
            <fieldset>
            <legend><span class="number">1</span> Project Name*</legend>
            {/* <label for="job">Project Name*</label> */}
            <input onBlur={(event) => {setPro(event.target.value)}} type="text" name="project_name" placeholder="Give your project a name" />
            <legend><span class="number">2</span>Choose a Product*</legend>
            {/* <label for="job">Product:</label> */}
            <select onChange={(event) => {setProduct(event.target.value)}} id="product" name="product">
            <optgroup label="Services">
            <option value="none" selected disabled hidden>
                Select an Option
            </option>
            <option value="Whitepaper">Whitepaper</option>
            <option value="Website Content">Website Content</option>
            <option value="Social Media Post">Social Media</option>
            <option value="Technical Write Up">Technical Writing</option>
            <option value="Copy Writing">Copy Writing</option>
            <option value="Blog">Blog Writing</option>
            <option value="Article">Article Writing</option>
            <option value="LOR">LOR</option>
            <option value="Resume">Resume/CV</option>
            <option value="SOP">SOP</option>
            <option value="Cover Letter">Cover Letter</option>
            <option value="Press Release">Press Release</option>
            <option value="Newsletter">Newsletter</option>
            <option value="Research Paper">Research Paper</option>
            <option value="Product Description">Product Description</option>
            <option value="Advertisement Script">Advertisement Script</option>
            <option value="Case Study">Case Study</option>
            <option value="Custom">Custom</option>            
            </optgroup>
            </select>
            {(sel==1) ? <><label for="job">Design:</label>
            <select onBlur={(event) => {setQuo(event.target.value)}} id="design" name="design">
            <optgroup label="design">
            <option value="none" selected disabled hidden>
                Select an Option
            </option>
            <option value="1">With Design</option>
            <option value="0">Without Design</option>
            </optgroup>
            </select></> : null}
            {(sel==2) ? <><label for="job">Number of Landing Pages:</label><textarea onBlur={(event) => {setLanding(event.target.value)}} name="landing" placeholder="Enter number of landing pages"/> 
            <label for="job">Number of Non Landing Pages:</label><textarea onBlur={(event) => {setNonLandingPage(event.target.value)}} name="nonlanding" placeholder="Enter number of non-landing pages"></textarea></>: null }
            {(sel==3 || sel==1) ? <textarea onBlur={(event) => {setBillableWords(event.target.value)}} name="billable" placeholder="Enter number of billable words" />: null }
            </fieldset>
            <fieldset>
            {(main==1) ? <><legend><span class="number">3</span> Topic</legend>
            <textarea onBlur={(event) => {setTopic(event.target.value)}} name="topic" placeholder="Enter your Topic"></textarea>
            <legend><span class="number">4</span> Industry</legend>
            <select onBlur={(event) => {setIndustry(event.target.value)}} id="Industry" name="industry">
            <optgroup label="Industry">
            <option value="none" selected disabled hidden>
                Select an Option
            </option>
            <option value="Software_and_Technology">Software and Technology</option>
            <option value="information_technology">Information Technology</option>
            <option value="marketing_and_advertisement">Marketing and Advertisement</option>
            <option value="finance">Finance</option>
            <option value="e_commerce">E-Commerce</option>
            <option value="academics">Academics</option>
            <option value="events_and_hospitality">Events and Hospitality</option>
            <option value="healthcare_and_sciences">Healthcare and Sciences</option>
            <option value="fashion">Fashion</option>
            <option value="travel">Travel</option>
            <option value="entertainment">Entertainment</option>
            <option value="sports_and_fitness">Sports and Fitness</option>
            </optgroup>
            </select>
            <legend><span class="number">5</span> Content Goals</legend>
            <textarea onBlur={(event) => {setContentGoals(event.target.value)}} name="contentgoals" placeholder="About Your School"></textarea>
            <legend><span class="number">6</span> Voice</legend>
            <textarea onBlur={(event) => {setVoice(event.target.value)}} name="voice" placeholder="About Your School"></textarea>
            <legend><span class="number">7</span> Target Audience</legend>
            <textarea onBlur={(event) => {setTargetAudience(event.target.value)}} name="targetaudience" placeholder="About Your School"></textarea>
            <legend><span class="number">8</span> Primary Keywords</legend>
            <textarea onBlur={(event) => {setPrimaryKeywords(event.target.value)}} name="primarykeywords" placeholder="About Your School"></textarea>
            <legend><span class="number">9</span> Reference Content</legend>
            <textarea onBlur={(event) => {setReferenceContent(event.target.value)}} name="referencecontent" placeholder="About Your School"></textarea>
            <legend><span class="number">10</span> Style and Tone</legend>
            <textarea onBlur={(event) => {setStyleTone(event.target.value)}} name="styletone" placeholder="About Your School"></textarea>
            <legend><span class="number">11</span> Referencing and Linking Preference</legend>
            <textarea onBlur={(event) => {setLinkingPreference(event.target.value)}} name="linkingpreference" placeholder="About Your School"></textarea>
            <legend><span class="number">12</span> Additional Information</legend>
            <textarea onBlur={(event) => {setAditionalInformation(event.target.value)}} name="additionalinformation" placeholder="About Your School"></textarea>
            <legend><span class="number">13</span> Add Attachment</legend>
            <input onBlur={(event) => {setAttachment(event.target.files[0])}} type="file" id="myfile" name="myfile"/>
            </> : null}
            <input type="submit" value="Proceed" />
            </fieldset>
            </form>
        </div>
    )
}

export default AddItm;


// {(delivery==2 || delivery==1) ? <label for="deadline">Delivery Deadline</label> : null}
//             {(delivery==1) ? <DatePickerComponent id="datepicker" change={onDateChange}  renderDayCell={onRenderDayCell} min={new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() +4)} placeholder="Enter date"/> : (delivery==2) ? <DatePickerComponent id="datepicker"  change={onDateChange} renderDayCell={onRenderDayCell} min={new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() +2)} placeholder="Enter date"/> : null}
//             <br/><br/><br/>