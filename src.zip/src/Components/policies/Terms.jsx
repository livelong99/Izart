import React, {useRef} from 'react';
import NavigationBar from "../PageComp/navigationBar.jsx"
import Footer from "../PageComp/Footer";
import "../../css/privacy_html.css";



const Terms = () => {

    return(
        <div>
        <NavigationBar></NavigationBar>
        <div class="types">
            <div class="darkBg">
            <div class="section01 about01 TermsBg">
          <div class="mainTxt">
          <div class="headone" style={{color: "#FFFFFF"}}>
              <p>Privacy Policy</p>
          </div>
          </div>
          </div>
          </div>
          </div>
          </div>)
}

export default Terms;